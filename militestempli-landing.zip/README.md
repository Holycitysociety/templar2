# Milites Templi — Minimal Landing

## Structure
- Transparent header: logo left (desktop), centered (mobile), menu right
- White hero with centered logo
- Black section placeholder

## Deploy on Netlify
- Connect this repo to Netlify
- No build command; publish directory is root
